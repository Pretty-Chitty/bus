import { SparkChit } from "../SparkChit";
import { EventChannel } from "../../utilities/EventChannel";
import { Chit } from "../Chit";
import { ClientTimeState } from "../ClientTimeState";
import { ClockDetails, samePasses } from "../ClockDetails";
import { Connection } from "../Connection";
import { ConnectionObject } from "../ConnectionObject";
import { Game } from "../Game";
import { RootChit } from "../RootChit";
import { ServerTime } from "../serverTransport/ServerTime";
import { ClientPrompts } from "./ClientPrompts";

export class ClientTime extends ConnectionObject {
  private lastSerializedState: { [chitId: string]: string } = {};

  public clientPrompt?: ClientPrompts<any, any>;

  constructor(
    public connection: Connection,
    public game: Game<any, any>,
    public clientTimeState: ClientTimeState,
  ) {
    super();

    this.serverTime = this.connection.get<ServerTime<any, any>>("ServerTime");

    this.register(this.clientTimeState.targetClock.on(() => this.processNewTargetClock()));
    this.register(
      this.clientTimeState.isWaitingOnAnimations.on((isWaiting) => {
        if (!isWaiting) this.playOn();
      }),
    );
    // A hold that is raised or lifted lets the board carry on from where it stopped
    this.register(this.clientTimeState.timelineHold.on(() => this.playOn(), false));

    this.clientTimeState.animationSpeedMultiplier.value =
      parseFloat(localStorage["animationSpeedMultiplier"] ?? "1") || 1;
    this.register(
      this.clientTimeState.animationSpeedMultiplier.on((targetSpeed) => {
        localStorage["animationSpeedMultiplier"] = targetSpeed;
      }),
    );

    this.clientTimeState.skipReplay.value = parseFloat(localStorage["skipReplay"] ?? "0") === 1;
    this.register(
      this.clientTimeState.skipReplay.on((skipReplay) => {
        localStorage["skipReplay"] = skipReplay ? "1" : "0";
      }),
    );

    this.clientTimeState.showLog.value = parseFloat(localStorage["showLog"] ?? "0") === 1;
    this.register(
      this.clientTimeState.showLog.on((showLog) => {
        localStorage["showLog"] = showLog ? "1" : "0";
      }),
    );
  }

  public currentClock = new EventChannel<ClockDetails>({ clock: 0, pass: -1 });
  private chitLookup: { [id: string]: Chit } = {};
  public maxClock = new EventChannel<ClockDetails>({ clock: 0, pass: -1 });
  public rootChit = new EventChannel<RootChit<any> | undefined>(undefined);
  public activeLog = new EventChannel<string | undefined>(undefined);
  private startTime = 1;

  public async gameLogs() {
    return await this.serverTime.gameLog();
  }

  public readonly findChit: (id: string) => Chit = (id: string) => {
    const result = this.chitLookup[id];
    if (!result) {
      throw new Error("Cannot find chit");
    }
    return result;
  };

  public readonly findChitUnsafe: (id: string) => Chit | undefined = (id: string) => {
    return this.chitLookup[id];
  };

  private serverTime: ServerTime<any, any>;

  public async setStartTime(newTime: number) {
    if (this.clientTimeState.targetClock.value <= newTime || newTime === 0) {
      this.clientTimeState.isLoading.value = true;

      const skip = this.clientTimeState.skipReplay.value || this.clientTimeState.skipInitialReplay;
      this.clientTimeState.skipInitialReplay = false;
      if (!skip) {
        this.startTime = newTime;
        this.clientTimeState.targetClock.value = newTime;
      } else {
        this.clientTimeState.goLive(this.maxClock.value.clock);
      }
    }
  }

  /** The furthest clock the board may play to right now (the game's latest, or a tutorial's hold) */
  private get playableClock() {
    return this.clientTimeState.playableClock(this.maxClock.value.clock);
  }

  /** Moves the board one clock on, if it is live, idle and allowed further */
  private playOn() {
    if (
      !this.clientTimeState.isWaitingOnAnimations.value &&
      this.clientTimeState.live.value &&
      this.clientTimeState.targetClock.value < this.playableClock
    ) {
      this.clientTimeState.targetClock.value++;
    }
  }

  public async newMaxClock(newMaxClock: ClockDetails) {
    const oldClock = this.maxClock.value;
    const isSamePass = samePasses(oldClock, newMaxClock);

    if (isSamePass && oldClock.clock === newMaxClock.clock) {
      return;
    }

    this.maxClock.value = newMaxClock;
    if (this.clientTimeState.live.value || !isSamePass) {
      if (
        !this.clientTimeState.isWaitingOnAnimations.value &&
        this.clientTimeState.targetClock.value < this.playableClock
      ) {
        this.clientTimeState.targetClock.value++;
      } else if (!isSamePass && !this.clientTimeState.isWaitingOnAnimations.value) {
        this.clientTimeState.targetClock.value = this.playableClock;
        this.processNewTargetClock();
      } else if (!this.clientTimeState.isWaitingOnAnimations.value) {
        // some other use has reset...
        this.clientTimeState.targetClock.value = this.playableClock;
      } else {
        this.processNewTargetClock();
      }
    }
  }

  private _states: { [stateId: number]: string } = {};
  private inflateSerializedResponse(newState: { [state: number]: string }, chitStates: { [id: string]: number }) {
    Object.assign(this._states, newState);
    return Object.fromEntries(Object.entries(chitStates).map(([key, value]) => [key, this._states[value]]));
  }

  private async processNewTargetClock() {
    const newTargetClock = this.clientTimeState.targetClock.value;
    const currentClock = this.currentClock.value;

    if (newTargetClock > this.playableClock) {
      // past the game's latest clock, or past a tutorial's hold (the Live and Forward buttons too)
      this.clientTimeState.targetClock.value = this.playableClock;
      return;
    }
    if (newTargetClock < 1) {
      this.clientTimeState.targetClock.value = 1;
      return;
    }

    // make sure our async operations don't get interrupted by auto-advancing the timeline
    const animationKey = `minimumAnimationDuration${Date.now()}`;
    this.clientTimeState.setAnimationState(animationKey, true);

    try {
      const response = await this.serverTime.serializeDelta(this.clientTimeState.targetClock.value);
      const serializedChits = this.inflateSerializedResponse(response.newStates, response.chits);

      // make sure nothing changed while we were waiting...
      if (this.clientTimeState.targetClock.value === newTargetClock && currentClock === this.currentClock.value) {
        if (newTargetClock >= this.startTime) {
          this.clientTimeState.isLoading.value = false;
        }

        // track the active log message
        this.activeLog.value = response.log?.message;
        this.clientPrompt?.fixActiveLog();

        // first make sure all chits exist (because they may link to each other)
        Object.entries(serializedChits).forEach(([id, value]) => {
          let chit = this.chitLookup[id];
          if (!chit) {
            const c = Chit.deflate(value, this.game);
            if (c) {
              chit = this.chitLookup[id] = c;
            }
          }
        });

        Object.values(this.chitLookup).forEach((chit) => {
          if (chit.id && !serializedChits[chit.id]) {
            // Back into its bag if it came from one; otherwise gone, as a visible fallback would keep it drawn
            chit.forgetFallbackUnlessHidden();
            if (chit.parentFallback) {
              chit.beginDeserializing();
              chit.setParent(chit.parentFallback, chit.parentOutlet ?? "graveyard");
              chit.doneDeserializing();
            } else {
              chit.removeFromParent();
            }
            delete this.lastSerializedState[chit.id];
          }
        });

        this.currentClock.value = response.clockDetails;

        // now actually load the new state
        const changedIds = new Set(
          Object.entries(serializedChits)
            .filter(([id, value]) => this.chitLookup[id] && this.lastSerializedState[id] !== value)
            .map(([id]) => id),
        );

        const chits: Chit[] = Object.entries(serializedChits)
          .filter(([id, value]) => this.chitLookup[id] && this.lastSerializedState[id] !== value)
          .map(([id]) => this.chitLookup[id]);

        chits.forEach((chit) => chit.beginDeserializing());

        Object.entries(serializedChits)
          .filter(([id]) => changedIds.has(id))
          .forEach(([id, value]) => {
            const chit = this.chitLookup[id];
            chit.deserialize(value, this.findChit);
            this.lastSerializedState[id] = value;
          });

        chits.forEach((chit) => chit.doneDeserializing());

        this.rootChit.value = this.findChit("root") as RootChit<any>;

        // sometimes deserializing chits does not result in animations (maybe a pure texture change?)
        // in that case, we need to make sure that the clock moves forward
        setTimeout(() => this.clientTimeState.setAnimationState(animationKey, false), 100);
      } else {
        this.clientTimeState.setAnimationState(animationKey, false);
      }
    } catch (e) {
      console.error(e);
      this.clientTimeState.setAnimationState(animationKey, false);
    }
  }

  /**
   * Changes a chit in this client's view only: `change` sets properties on the local copy and the
   * renderer picks it up (and animates it) like any change from the server. The server never hears
   * of it. A later server change to the same chit overwrites it; `restoreChit` puts it back sooner.
   * For tutorials and demos (a card flipping over while the narration talks about it).
   */
  public poseChit(chit: Chit, change: (chit: Chit) => void) {
    chit.beginDeserializing();
    try {
      change(chit);
    } finally {
      chit.doneDeserializing();
    }
  }

  /** Puts a chit's properties back to the server's state for the moment on screen, undoing `poseChit`. */
  public restoreChit(chit: Chit) {
    const value = chit.id ? this.lastSerializedState[chit.id] : undefined;
    if (!value) return;
    chit.beginDeserializing();
    chit.deserialize(value, this.findChit, true);
    chit.doneDeserializing();
  }

  public async chitHistory(chits: Chit[]) {
    const sparkHistory = await this.serverTime.chitHistory(chits.map((s) => s.id!));
    const result: { [id: string]: { clock: number; chit: Chit }[] } = {};

    const chitLookup: { [id: string]: Chit } = Object.entries(this.chitLookup).reduce(
      (acc, [id, chit]) => {
        const serialized = chit.serialize();
        const c = Chit.deflate(serialized, this.game);
        if (c) {
          acc[id] = c;
        }
        return acc;
      },
      {} as { [id: string]: Chit },
    );
    const findChit = (id: string) => chitLookup[id];

    Object.keys(chitLookup).forEach((id: string) => {
      chitLookup[id].deserialize(this.chitLookup[id].serialize(), findChit);
    });

    Object.entries(sparkHistory).forEach(([id, history]) => {
      result[id] = [];
      history.forEach((h: any) => {
        const c = Chit.deflate(h.state, this.game);
        if (c) {
          c.deserialize(h.state, findChit);
          result[id].push({ clock: h.clock, chit: c });
        }
      });
    });
    return result;
  }
}
