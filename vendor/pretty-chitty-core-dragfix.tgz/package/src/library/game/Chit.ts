import { ChitRenderInstance } from "../rendering/ChitRenderInstance";
import { ChitRenderSpec } from "../rendering/ChitRenderSpec";
import type { Turn } from "./Turn";
import { FixChildOutlets, NonEditable, Ordered } from "../utilities/Annotations";
import { ObjectWithProps } from "../utilities/ObjectWithProps";
import { ChitPick, DragPick, DragTarget } from "./Pick";
import { Vector2 } from "three";
import { OrderedOutlet } from "./OrderedOutlet";
import { SparkChit } from "./SparkChit";
import StaticChitTypeRegistry from "./StaticChitTypeRegistry";
import type { Game } from "./Game";
import { IUpdatingCanvas } from "../utilities/IUpdatingCanvas";
import { ImageSpec } from "../utilities/CanvasStack/CanvasOperations";

export const ORDERED_CHILDREN = "orderedChildren";

const EXTRA_SERIALIZATION_PROPS_ARRAY = ["id", "_parent", "_parentOutlet", "_parentOutletIndex", "_parentFallback"];
const EXTRA_SERIALIZATION_PROPS_SET = new Set(EXTRA_SERIALIZATION_PROPS_ARRAY);
const DELETED_SERIALIZED = JSON.stringify({ ____deleted: true });

const dirtyProxyCache = new WeakMap<object, object>();

function wrapWithDirtyProxy(value: any, chit: Chit): any {
  if (value === null || value === undefined) return value;
  if (typeof value !== "object") return value;
  if (value instanceof Chit || value instanceof OrderedOutlet) return value;

  const existing = dirtyProxyCache.get(value);
  if (existing) return existing;

  const proxy = new Proxy(value, {
    set(target, prop, newValue) {
      if (typeof newValue === "object" && newValue !== null && !(newValue instanceof Chit) && !(newValue instanceof OrderedOutlet)) {
        target[prop] = newValue;
      } else {
        target[prop] = newValue;
      }
      chit.markDirty();
      return true;
    },
    deleteProperty(target, prop) {
      delete target[prop];
      chit.markDirty();
      return true;
    },
    get(target, prop) {
      const val = target[prop];
      if (typeof val === "function") return val.bind(proxy);
      if (typeof val === "object" && val !== null && !(val instanceof Chit) && !(val instanceof OrderedOutlet)) {
        return wrapWithDirtyProxy(val, chit);
      }
      return val;
    },
  });

  dirtyProxyCache.set(value, proxy);
  return proxy;
}

export type ChitClick = () => void;
/** Called when a dragged chit is dropped on a target; returning `false` says the drop was refused (a
 *  tutorial's guard), so the dragged chit goes back where it came from instead of onto the target. */
export type ChitDrag = (dropOn: Chit) => void | boolean;

export type HiddenPropertySerializationRule = {
  fields: "all" | string[];
  playerIds: string[];
};

export type PanelTab = {
  color: string;
  icon: IUpdatingCanvas | ImageSpec;
};

let CHIT_CREATED_ORDER = 0;
export class Chit extends ObjectWithProps {
  /** @internal */
  @NonEditable public type: string = "chit";

  @NonEditable public id?: string;

  constructor() {
    super();
    FixChildOutlets(this);
  }

  @Ordered
  public orderedChildren = new OrderedOutlet<Chit>();

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public render(spec: ChitRenderSpec) {}

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  public shouldRenderChild(childChit: Chit): boolean {
    return true;
  }

  // used if this chit is the root of a panel
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  getSparks(context: "panel" | "dropdown" | "endgame"): SparkChit[] {
    return [];
  }

  public add<T extends Chit>(chit: T, outlet?: string): T {
    if (!outlet) {
      this.orderedChildren.add(chit);
    } else {
      chit.setParent(this, outlet);
    }
    return chit;
  }

  public remove(chit: Chit) {
    if (chit.parent !== this) {
      throw new Error("Cannot remove child that isnt mine");
    }
    chit.setParent();
  }

  public removeFromParent() {
    this.setParent();
  }

  @NonEditable private _parentOutletIndex?: number;
  public get parentOutletIndex(): number | undefined {
    return this._parentOutletIndex;
  }

  @NonEditable private _parentOutlet?: string;
  public get parentOutlet(): string | undefined {
    return this._parentOutlet;
  }

  @NonEditable private _parent?: Chit;
  public get parent(): Chit | undefined {
    return this._parent;
  }

  // if a chit comes from a "bag" or something, this will be the "parent" that it should effectively go to or come from
  /** @internal */
  @NonEditable private _parentFallback?: Chit;
  public get parentFallback(): Chit | undefined {
    return this._parentFallback;
  }
  public set parentFallback(newValue: Chit | undefined) {
    this._parentFallback = newValue;
    this.markDirty();
  }

  @NonEditable private _lastParent?: Chit;

  /** @internal */
  public get lastParent(): Chit | undefined {
    return this._lastParent;
  }

  public get panelTab(): PanelTab | undefined {
    return undefined;
  }

  toJSON() {
    if (!this.id) {
      throw new Error("Attempting toJSON on a chit without an ID");
    }
    return {
      __chit_id: this.id,
    };
  }

  toString() {
    return `${this.chitTypeName()} ${this.id}`;
  }

  /** @internal */
  chitTypeName() {
    const result = Object.getPrototypeOf(this).constructor.name;
    if (this.parentFallback) {
      return `${result}-${this.parentFallback.id}-`;
    }
    return result;
  }

  //
  //
  // Private or "protected"
  // I can't safely mark stuff as "protected" and make it visible to other parts of the system and not visible to games that extend Chit
  // so anything that should not be used by a game is prefixed with "" which should put it at the bottom of the autocomplete list
  // and make it clear that it shouldn't be touched
  //
  //

  /** @internal */
  @NonEditable public renderInstance?: ChitRenderInstance;
  @NonEditable private _version = 0;
  @NonEditable private _createdOrder = ++CHIT_CREATED_ORDER;

  /** @internal */
  @NonEditable public _dirty = true;
  @NonEditable private _lastSerialized?: string;
  @NonEditable private _instrumented = false;

  /** @internal */
  public markDirty() {
    const wasDirty = this._dirty;
    this._dirty = true;
    if (!wasDirty || !this.id) {
      try {
        this.currentTurn.notifyChitDirty(this);
      } catch {
        // no current turn yet — chit will be discovered when parented
      }
    }
  }

  /** @internal */
  public get version() {
    return this._version;
  }

  /** @internal */
  public get createdOrder() {
    return this._createdOrder;
  }

  @NonEditable private _game?: Game<any, any>;

  /** @internal */
  public get game(): Game<any, any> | undefined {
    if (!this._game) {
      this._game = this.parent?.game;
    }
    return this._game;
  }

  /** @internal */
  public set game(newGame: Game<any, any>) {
    this._game = newGame;
  }

  @NonEditable
  private _onClick?: ChitClick;

  /** @internal */
  public get onClick(): undefined | ChitClick {
    return this._onClick;
  }

  /** @internal */
  public set onClick(newValue: undefined | ChitClick) {
    this._onClick = newValue;
    this.notifyChange("onClick");
  }

  @NonEditable
  private _onDrag?: ChitDrag;

  /** @internal */
  @NonEditable
  public dropTargets?: Chit[];

  @NonEditable
  public isDropTarget = false;

  /** @internal */
  public set onDrag(newValue: undefined | ChitDrag) {
    this._onDrag = newValue;
    this.notifyChange("onClick");
  }

  /** @internal */
  public get onDrag(): undefined | ChitDrag {
    return this._onDrag;
  }

  /**
   * Returns true if the chit is currently clickable
   */
  public get isClickable(): boolean {
    return !!this.onClick || !!this.onDrag;
  }

  @NonEditable private _lockedBy?: Turn<any, any, any>;

  public get currentTurn(): Turn<any, any, any> {
    if (this._lockedBy) {
      return this._lockedBy;
    }
    if (this.parent) {
      return this.parent.currentTurn;
    }
    throw "No current turn";
  }

  public functionallyIdentical(other: Chit) {
    const myProto = Object.getPrototypeOf(this);
    const otherProto = Object.getPrototypeOf(other);
    if (myProto !== otherProto) {
      return false;
    }

    const compare = (a: any, b: any): boolean => {
      if (a === b) {
        return true;
      }
      if ((a && !b) || (!b && a)) {
        return false;
      }

      const aIsArray = Array.isArray(a);
      const bIsArray = Array.isArray(b);
      if (aIsArray && bIsArray) {
        if (a.length !== b.length) {
          return false;
        }
        return !a.find((item, index) => !compare(item, b[index]));
      }

      const aIsChit = a instanceof Chit;
      const bIsChit = b instanceof Chit;
      if (aIsChit && bIsChit) {
        return a.functionallyIdentical(b);
      }

      const aIsOrderedOutlet = a instanceof OrderedOutlet;
      const bIsOrderedOutlet = b instanceof OrderedOutlet;
      if (aIsOrderedOutlet && bIsOrderedOutlet) {
        return compare(a.copy(), b.copy());
      }

      const aIsObject = a instanceof Object;
      const bIsObject = b instanceof Object;
      if (aIsObject && bIsObject) {
        const aKeys = Object.keys(a);
        const bKeys = Object.keys(b);
        if (aKeys.length !== bKeys.length) {
          return false;
        }
        return !aKeys.find((key) => !compare(a[key], b[key]));
      }

      return a === b;
    };

    const myProps = this.serializationProps;
    const otherProps = other.serializationProps;
    if (myProps.length !== otherProps.length || JSON.stringify(myProps) !== JSON.stringify(otherProps)) {
      return false;
    }

    // find a prop that isn't the same
    return !this.serializationProps.find((prop) => {
      // indexes will of course be different... no need to stress on these
      if (prop.startsWith("_") || prop === "id") {
        return false;
      }

      const myValue = (this as any)[prop];
      const otherValue = (other as any)[prop];
      return !compare(myValue, otherValue);
    });
  }

  /** @internal */
  public get lockedBy() {
    return this._lockedBy;
  }

  /** @internal */
  public lock(turn: Turn<any, any, any>): void {
    if (this._lockedBy && this._lockedBy !== turn) {
      throw new Error("Chit is already locked");
    }
    this._lockedBy = turn;
  }

  /** @internal */
  public confirmLock(turn: Turn<any, any, any>): void {
    if (this._lockedBy && this._lockedBy !== turn) {
      throw new Error("Chit is already locked");
    }
  }

  /** @internal */
  public unlock(turn: Turn<any, any, any>): void {
    if (this._lockedBy && this._lockedBy !== turn) {
      throw new Error("Chit is locked by someone else?");
    }
    this._lockedBy = undefined;
  }

  /** @internal */
  public removeChild(child: Chit, parentOutlet?: string) {
    if (parentOutlet) {
      const existingParentOutletValue = (this as unknown as any)[parentOutlet];
      if (existingParentOutletValue === this) {
        (this as unknown as any)[parentOutlet] = undefined;
      } else if (existingParentOutletValue instanceof OrderedOutlet) {
        existingParentOutletValue.remove(this);
      } else {
        (this as any).children = (this as any).children.filter((c: Chit) => c !== child);
      }
    } else {
      (this as any).children = (this as any).children.filter((c: Chit) => c !== child);
    }
  }

  public setParent(newValue?: Chit, parentOutlet?: string, parentOutletIndex?: number) {
    if (this._parent === newValue && this._parentOutlet === parentOutlet) {
      if (this._parentOutletIndex !== parentOutletIndex) {
        this._parentOutletIndex = parentOutletIndex;
        this.markDirty();
      }
      return;
    }

    if (this._parent !== newValue) {
      this._lastParent = this._parent;
    }

    const oldParent = this._parent;

    if (this._parent) {
      if (!this._parentOutlet) {
        throw new Error("Cannot have a parent without a parent outlet");
      }

      const oldOutlet = this._parentOutlet;

      this._parent = undefined;
      this._parentOutlet = undefined;
      this._parentOutletIndex = undefined;

      (oldParent as any).children = (oldParent as any).children.filter((c: Chit) => c !== this);

      const existingParentOutletValue = (oldParent as any)[oldOutlet];
      if (existingParentOutletValue === this) {
        (oldParent as any)[oldOutlet] = undefined;
      } else if (existingParentOutletValue instanceof OrderedOutlet) {
        existingParentOutletValue.remove(this);
      }
    }

    if (newValue) {
      this._parent = newValue;
      this._parentOutlet = parentOutlet;
      this._parentOutletIndex = parentOutletIndex;
      newValue.children.push(this);

      if (newValue.renderInstance) {
        newValue.renderInstance.childAdded(this, this.renderInstance);
      } else {
        this.renderInstance = undefined;
      }
    }

    this.markDirty();
    if (oldParent) oldParent.markDirty();
    if (newValue) newValue.markDirty();

    this.notifyChange("parent");
  }

  /** @internal */
  @NonEditable public children: Chit[] = [];

  /**
   * Visits this chit and everything under it, depth first. Return false from `fn` to skip a chit's
   * children. Handy in tutorial selectors and checks ("every card on the table").
   */
  public walk(fn: (c: Chit) => boolean | void) {
    if (fn(this) === false) {
      return;
    }
    this.children.forEach((child) => child.walk(fn));
  }

  private get serializationProps() {
    return [...this.props, ...EXTRA_SERIALIZATION_PROPS_ARRAY];
  }

  /** @internal */
  public screenCoordinates(): Vector2 | undefined {
    return this.renderInstance?.screenCoordinates() ?? this.parent?.screenCoordinates();
  }

  /** @internal */
  public canRender() {
    return true;
  }

  /** @internal */
  @NonEditable public isDeserializing = false;

  /** @internal */
  public doneDeserializing() {
    if (this.isDeserializing) {
      this.isDeserializing = false;
      this.notifyChange("deserialized");
    }
  }

  /** @internal */
  public beginDeserializing() {
    this.isDeserializing = true;
  }

  /** @internal */
  public deserialize(serialized: string, findChit: (id: string) => Chit, propsOnly = false) {
    const j = JSON.parse(serialized);

    if (!propsOnly) {
      this._version++;
      if (j.____deleted) {
        this.forgetFallbackUnlessHidden();
        this.setParent();
        return;
      }
    }

    const inflateValue = (value: any): any => {
      if (!value) {
        return value;
      }
      if (Array.isArray(value)) {
        return value.map(inflateValue);
      } else if (Object.getPrototypeOf(value).constructor.name === "Object") {
        // only want to do this for vanilla objects
        if (value.__chit_id) {
          return findChit(value.__chit_id);
        }

        return Object.entries(value).reduce((acc, [key, value]) => {
          (acc as any)[key] = inflateValue(value);
          return acc;
        }, {});
      } else {
        return value;
      }
    };

    // expanded props will introduce undefined for things that used to be there but aren't
    this.expandedPropsFromJson(j).forEach((key) => {
      if (EXTRA_SERIALIZATION_PROPS_SET.has(key)) {
        return;
      }

      const value = (j as any)[key];
      if (value?.___orderedOutlet) {
        (this as any)[key].deserialize(value.___orderedOutlet.map(inflateValue));
      } else {
        (this as any)[key] = inflateValue(value);
      }
    });

    if (!propsOnly) {
      this.id = j.id;

      this._parentFallback = inflateValue(j._parentFallback);

      if (this._version === 1 && this._parentFallback) {
        this.setParent(this._parentFallback, j._parentOutlet ?? "graveyard");
      }

      this.setParent(inflateValue(j._parent), j._parentOutlet, j._parentOutletIndex);
    }

    this.markDirty();
    this._lastSerialized = undefined;
  }

  /**
   * Let chits decide who can see what.  (Allow privacy of chits)
   * @param _playerIds
   * @returns
   */
  public hiddenPropertiesForSerialization(_playerIds: string[]): HiddenPropertySerializationRule[] | undefined {
    return undefined;
  }

  private instrumentForDirtyTracking() {
    if (this._instrumented) return;
    this._instrumented = true;

    for (const key of this.serializationProps) {
      const descriptor = Object.getOwnPropertyDescriptor(this, key);
      if (descriptor && (descriptor.get || descriptor.set)) continue;

      let value = (this as any)[key];
      Object.defineProperty(this, key, {
        enumerable: true,
        configurable: true,
        get: () => {
          if (typeof value === "object" && value !== null && !(value instanceof Chit) && !(value instanceof OrderedOutlet)) {
            return wrapWithDirtyProxy(value, this);
          }
          return value;
        },
        set: (newValue: any) => {
          if (newValue !== value) {
            value = newValue;
            this.markDirty();
          }
        },
      });
    }
  }

  /** @internal */
  public serialize(playerIds?: string[]): string {
    this.instrumentForDirtyTracking();

    if (!this._dirty && this._lastSerialized !== undefined) {
      return this._lastSerialized;
    }

    const result = JSON.stringify(
      this.serializationProps.reduce(
        (acc, key) => {
          const value = (this as any)[key];
          acc[key] = value;
          return acc;
        },
        {
          __chitType: Object.getPrototypeOf(this).constructor.name,
          __hiddenProps: playerIds ? this.hiddenPropertiesForSerialization(playerIds) : undefined,
        } as { [key: string]: any },
      ),
    );

    this._dirty = false;
    this._lastSerialized = result;
    return result;
  }

  //
  //
  // Static methods
  //
  //

  /** @internal */
  public static fixVisibility(serialized: string, playerId: string) {
    const data = JSON.parse(serialized);
    if (data.__hiddenProps) {
      const hiddenPropRules = data.__hiddenProps as HiddenPropertySerializationRule[];
      const rule = hiddenPropRules.find((rule) => rule.playerIds.indexOf(playerId) !== -1);
      if (rule) {
        if (rule.fields === "all") {
          Object.keys(data)
            .filter((a) => a !== "id" && !a.startsWith("_") && !data[a]?.___orderedOutlet)
            .forEach((key) => {
              delete data[key];
            });
        } else {
          rule.fields
            .filter((k) => {
              if (data[k]?.___orderedOutlet) {
                throw new Error("Cannot mask ordered outlets");
              }
              return true;
            })
            .forEach((key) => {
              delete data[key];
            });
        }
        delete data.__hiddenProps;
        return JSON.stringify(data);
      }
    }
    return serialized;
  }

  /*
   * Creates a new chit from the serialized spec.
   */
  /** @internal */
  public static deflate(serialized: string, game: Game<any, any>) {
    const { __chitType, ____deleted } = JSON.parse(serialized);
    if (____deleted) {
      return undefined;
    }
    const ChitType = game.chitLibrary[__chitType] ?? StaticChitTypeRegistry[__chitType];
    if (!ChitType) {
      throw new Error(`Chit Type ${__chitType} not found`);
    }
    const result = new ChitType();
    result.game = game;
    return result;
  }

  /** Like `chit.walk` over several roots, visiting each chit (by id) once. */
  public static walk(chits: Chit[], fn: (c: Chit) => boolean | void) {
    const seenIds = new Set();
    chits.forEach((chit) =>
      chit.walk((chit) => {
        if (chit.id) {
          if (seenIds.has(chit.id)) {
            return false;
          }
          seenIds.add(chit.id);
        }
        return fn(chit);
      }),
    );
  }

  public static pick<T extends Chit>(
    chit: T | (T | undefined | null | false)[] | OrderedOutlet<T>,
    cb: (chit: T) => void | Promise<void>,
  ) {
    const result = new ChitPick<T>();
    result.chits =
      chit instanceof OrderedOutlet ? chit.copy() : Array.isArray(chit) ? (chit.filter((c) => c) as T[]) : [chit];
    result.cb = cb;
    return result;
  }

  /**
   * Creates a DragPick options for the chit(s).  Create an array of DragTargets that these chits can be dropped on.
   * @param chit A single chit, an array of chits (that can be empty-ish or nullish and ignored), or an OrderedOutlet of chits
   * @param targets An array of DragTargets that the chits can be dropped on
   * @returns A DragPick instance configured with the specified chits and targets
   */
  public static dragPick<T extends Chit>(
    chit: T | (T | undefined | null | false)[] | OrderedOutlet<T>,
    targets: DragTarget<any, T> | DragTarget<any, T>[],
  ) {
    const result = new DragPick<T>();
    result.chits =
      chit instanceof OrderedOutlet ? chit.copy() : Array.isArray(chit) ? (chit.filter((c) => c) as T[]) : [chit];
    result.dropTargets = Array.isArray(targets) ? targets : [targets];
    return result;
  }

  /**
   * A deleted chit keeps its `parentFallback` only when that fallback hides its children, as a bag does: then the
   * chit is "back in the bag", invisible, and can come out again. Any other fallback (a piece a new chit was made to
   * come from) would keep the deleted chit alive and drawn beside it, since the renderer never destroys a parentless
   * chit that still has a fallback. Undo deletes chits this way, so without this an undone piece lingers on screen.
   * @internal
   */
  public forgetFallbackUnlessHidden() {
    if (this._parentFallback && this._parentFallback.shouldRenderChild(this)) {
      this._parentFallback = undefined;
    }
  }

  /** @internal */
  public static deletedIfSerialized(): string {
    return DELETED_SERIALIZED;
  }
}
